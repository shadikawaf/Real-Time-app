# A03 Production

Available Scripts
----------------------


### npm install

Install your dependencies.



### npm start

Start the app. <br>
To see it in a browser, go to http://localhost:3000.
<pre>
<li><li>1- https://cscloud7-157.lnu.se/  is the URL of my application.
</li>
<br />
</li> 
<br />
</pre>

<pre>
<li><li>2- In order to protect my application, I used a reserved proxy by using Nginx. For my token webhook and GitLab, I used environment variables. Using secure communication in the proxy 'HTTPS.' The HTTPS Testing if the secret token is contained in the records that come to my webhook. Ensuring the application prevents the javascript from accessing the API or Gitlab.
</li>
<br />
</li> 
<br />
</pre>

<pre>
<li>3-<br />
_ _Nginx is the reserved proxy that I used for the traffic directing to 3000 parts from the port of 443. The reverse proxy also manages TLS encryption between a client and a server.
<br />
_ _Process Manager PM2 was used to reset the program if any crash happened and assure the running of the program. 
<br />
_ _TLS is used to protect the data exchanged between the server and the client-side by encrypting the connection.
<br />
_ _To instruct a program on operating in a specific environment, I used environment variables. I used the environment variable to specify the mode in which my program should execute and save the Gitlab and webhook tokens.  

</li>
<br />
</li> 
<br />
</pre>

<pre>
<li><li>4- For the development, I used custom code to test multiple parts of my application, such as events emissions and WebSocket. I used Morgan as a logger to test in localhost 
When an application is in production, it can manage more traffic.
</li>
<br />
</li> 
<br />
</pre>


<pre>
<li><li>5- Moment was beneficial to format the time and present it in a usable way. I used socket io to connect the server and the client to obtain real-time communication. As there are several weekly downloads from various developers, Modules are secure enough.

</li>
<br />
<br />
</pre>

<pre>
<li><li>6- I did not implement any extra features for this project.
</li>
<br />
<br />
</pre>

<pre>
<li><li>7- I'm happy with my program, particularly the structure, because it's simple and easy to understand and adjust and meets the assignment's demands.
In terms of the enhancement area, I believe the view could be expanded; even though this is a backend program, I believe it is OK as is.

</li>
<br />
<br />
</pre>


<pre>
<li><li>8- The TIL for this section of the course is to learn how to utilise Socket.io to connect the client and server sides and use environment variables and certificates. Run a program on a server and encrypt it with HTTPS. Knowing how to get through PM2, I got my hands on tokens, a webhook, and Nginx and set up a reverse proxy.
</li>
<br />
<br />
<br />
</pre>






[Video presentation](https://youtu.be/y_ie7lJTx1M)


